"""moose controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot, Receiver
import struct

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

receiver = robot.getDevice("receiver")
receiver.enable(timestep)

while robot.step(timestep) != -1:
    arr = []
    while (receiver.getQueueLength() > 0):
        receivedData = receiver.getData()
        tup = struct.unpack('f f', receivedData)
        arr.append(tup)
        print(arr)
        receiver.nextPacket()
  
